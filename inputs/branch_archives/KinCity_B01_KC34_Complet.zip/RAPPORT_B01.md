# Kin City KC34 — Rapport B01 · Hôtel de ville

**Mission :** première passe de développement Art déco et préparation de l'intérieur `city_hall` pour intégration par B09. **Statut :** PRET POUR REVUE, NON FUSIONNÉ ET NON TESTÉ DANS ROBLOX STUDIO.

## Réalisé

- Définition des **six salles** de l'Hôtel de ville avec programmes civiques spécifiques, titres et cheminements narratifs; les trois salles canoniques et trois extensions ont été vérifiées dans le code V3 original.
- Nouveau module `CityHallScene.luau` produisant uniquement des frises, des rayons géométriques, de la signalétique et un emblème civique mural par salle. Une seule couche nommée `KinB01CityHallDecor` est montée dans l'intérieur. Les pièces sont toutes non-collidables.
- Validation préalable stricte de `place_key`, version des contrats, nom du Model, attribut `KinPlaceKey`, origine et présence des six salles; génération idempotente avec remplacement de la couche précédente après une construction réussie.
- Trois profils : **LITE 54**, **STANDARD 84** et **SHOWCASE 114** pièces décoratives théoriques, sous des plafonds B01 respectifs de 64, 128, 200.
- Fichier JSON source pour la scène, export Luau déterministe, fichier `recipe.json` au format de contribution B09, outil de génération, scripts de preview et de rollback limités à `PlaceId=0` dans Studio.
- Aucun changement apporté à `WorldBuilder`, aux catalogues, à `InteriorWings`, aux portes, au kiosque stub, à la façade ou au système de transport; aucune ressource commerciale distribuée.

## Tests réellement exécutés

- **18 tests Python sur 18 : PASS**. Vérifications de coordonnées des six salles, IDs, portes réciproques, ancres, exclusion des plaques à proximité, budgets et générateur de preview.
- **4 fichiers Luau vérifiés lexicalement : PASS** (délimiteurs et littéraux, pas analyse de grammaire réelle).
- Les traces se trouvent dans `contrib/places/city_hall/tests/`.

## Tests NON réalisés

- Test de compilation/exécution Luau dans Roblox Studio.
- Test de rendu, collisions en conditions réelles, framerate mobile, ombres, sons et visibilité des six pièces.
- Essai d'intégration dans l'archive exacte KC33/B09, non présente dans cette session; seul le ZIP V3 original a été mis à disposition et inspecté. Le SHA KC33 reporté par B09 est conservé dans le handoff mais **n'a pas pu être recalculé localement**.
- Test des 16 portes réseau, 2 portes de B01 ou d'une vraie Place séparée; pas de Place publiée.

## Actions requises de B09

1. Contrôler le `handoff_B01.json` et les SHA-256, vérifier le SHA du ZIP KC33 dans B09 et accepter ou rejeter les divergences de contrat avant toute fusion.
2. Examiner `contrib/places/city_hall/docs/RFC_B09_B01_001.md` et concevoir l'intégration du loader uniquement dans `city_hall`, en conservant le repli KC33 lorsque la contribution est absente.
3. Qualifier le script de prévisualisation sur une copie locale Studio, puis en staging publié si le loader est accepté; ne rien exécuter en production.
4. Intégrer éventuellement des meubles/couronnements importés du pack commercial après vérification des droits et coûts; aucun n'a été ajouté automatiquement par B01.
5. Arbitrer l'écart de dimensions entre bounds canoniques `110×100` et les extensions jusqu'à x=±105 et z=+104 (RFC transversale B09 requise).

## Rollback

Exécuter `preview/ROLLBACK_B01_COPIE_LOCALE.luau` sur une copie locale PlaceId=0, ou supprimer uniquement `KinB01CityHallDecor`. En B09, retirer l'appel au module B01 et revenir à la baseline KC33. Aucun identifiant d'accès, PlaceId, porte ou catalogue n'a été modifié.
