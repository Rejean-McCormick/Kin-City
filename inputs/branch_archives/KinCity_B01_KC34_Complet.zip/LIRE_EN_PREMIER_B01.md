# B01 — Accueil civique / Hôtel de ville

**Pour B09 :** déposer `patch_B01/` dans un dossier temporaire à côté de la baseline KC33, puis vérifier `handoff_B01.json` et tous les hashes. Le paquet ne prétend **pas** avoir été fusionné dans `WorldBuilder`; les fichiers restent tous dans `contrib/places/city_hall/`.

**Pour tester localement dans Studio :** lire `contrib/places/city_hall/README.md`, sauvegarder une copie locale de la Place, puis exécuter en Command Bar `preview/PREVIEW_B01_COPIE_LOCALE.luau`. Elle nécessite un `Intérieur — city_hall` déjà généré avec ses six salles et `KinInteriorOrigin`. La commande refuse les Places publiées et ne modifie aucune porte. Un rollback distinct est fourni.

**Fichiers clés :** `CityHallScene.luau` (constructeur), `CityHallSpec.luau` (spec Luau générée), `city_hall_scene.json` (source), `recipe.json` (contrat B09 non raccordé), `tests/` (18 contrôles), `docs/RFC_B09_B01_001.md` (demande d'intégration).

La session avait accès au ZIP V3 original, mais pas aux archives KC33 et B09 précédemment générées. Par conséquent, B09 doit rejouer ses tests de compatibilité avant toute acceptation.
