# B04 — Rapport de livraison Campus UCKK

## Références du projet

- **Place** : `campus` ; propriétaire B04 ; contrat annoncé `KC34-DOC-1.0`.
- **Sources inspectées physiquement ici** : `KinCity_ArtDeco_V3_Complet (1).zip`, fourni par l'utilisateur.
- **Limite de vérification** : l'archive KC33 et le package B09 livrés précédemment ne sont **pas disponibles dans la session de fichiers actuelle**. Leur contenu et leur intégrité n'ont donc pas pu être revérifiés par cette passe. Le handoff porte l'empreinte de KC33 annoncée auparavant, en attente du contrôle effectif B09.
- **Aucune Place Roblox publiée, aucun PlaceId renseigné et aucune source commune modifiée**.

## Travail réalisé

1. Répertoire limité à `contrib/places/campus/` compatible avec l'organisation B09, avec son `recipe.json` et un programme pédagogique salle par salle.
2. Module Luau autonome `CampusDecor.luau` pour 6 salles : panneaux Art déco, moulures bronze, repères visuels bleu-gris UCKK `#758EA6` et sarcelle KOALI `#1E6864`.
3. Trois profils : `LITE` environ **18 Parts**, `STANDARD` **28 Parts**, `SHOWCASE` **36 Parts**, en complément optionnel de l'intérieur existant ; valeurs calculées à partir des branches de code, non mesurées dans Studio.
4. Décoration non-collidable et idempotente ; aucune modification de `campus.exit`, `campus.lobby.spawn`, `hall.board_01`, des quatre passages d'extension ni des deux portails canoniques.
5. Script autonome de prévisualisation `INSTALLER_B04_PREVIEW_LOCAL.luau`, destiné **uniquement** à une copie locale Studio (PlaceId 0) existante ; aucun installateur de publication.
6. 12 tests statiques contre le ZIP original qui couvrent l'identité, les portes, les salles, les couleurs, les protections et la recette. **12/12 passent**. Aucun test Studio/Luau complet effectué.

## Architecture pédagogique des six espaces

| Salle | Position canonique | Mission | Décoration proposée |
|---|---|---|---|
| `campus.lobby` | `(0,0,-29)` | Accueil et orientation | Deux panneaux latéraux et filets bronze |
| `campus.gallery` | `(-27,0,17)` | Cours et méthode | Plaque du fond, sans toucher au tableau interactif |
| `campus.chamber` | `(27,0,17)` | Laboratoire | Plaque didactique et moulure |
| `campus.west_wing` | `(-79,0,7)` | Ateliers | Signalétique sobre |
| `campus.east_wing` | `(79,0,7)` | Exploration | Signalétique, pédagogie expérimentale |
| `campus.rear_atrium` | `(0,0,76)` | Expositions et rencontres | Repères de l'atrium, sans recouvrir la sculpture existante |

## Non réalisé / à intégrer par B09

- Raccordement de `CampusDecor.build(...)` dans `WorldBuilder`/`InteriorGenerator` selon les interfaces partagées réellement livrées par B09.
- Ajout au pipeline des installateurs KC34 : le `recipe.json` n'est pas un chargeur opérationnel.
- Validation sur une copie locale Roblox Studio, particulièrement l'orientation et lisibilité des `SurfaceGui`.
- Validation de chaque accès, escalier, ascenseur, interaction pédagogique et porte retour.
- Tests dans une véritable Place `campus` publiée en staging, intégrée dans une expérience multi-Place commune.
- Mesures réelles FPS/mémoire/mobile pour chaque profil graphique et revues de collision.
- Révision éventuelle des bounds 110×100 après ADR B09 ; les ailes réelles dépassent ce gabarit.

## Remise attendue par B09

Le fichier `handoff_B04.json` inventorie les fichiers à importer, leurs SHA-256 et la classe `LOCAL`. Le bon processus est de **comparer** ces fichiers avec `contrib/places/campus/` du dépôt B09 en cours, de ne pas remplacer aveuglément sa recette si elle a évolué et de valider par les outils B09 avant toute fusion. Le module restant déconnecté du runtime, la remise ne peut pas être qualifiée de release Roblox.

## Rollback

Supprimer les fichiers B04 déclarés dans le handoff; sur la copie locale de Studio, supprimer seulement le dossier `B04_CampusDecor_KC34` créé à l'intérieur du modèle `Intérieur — campus` ou restaurer la copie `.rbxl` sauvegardée. Tous les fichiers canoniques restent inchangés.
