# Démarrage/continuation de branche B04 — Campus UCKK

Tu développes la **Place Roblox `campus`**, correspondant à l'Université King Klown, dans l'architecture Kin City / Koali. Tu es **B04**, et la branche **B09** possède les contrats partagés et réalise les intégrations. La **Place ville** appartient à B10. Ne modifies pas unilatéralement leurs systèmes.

**Sources de travail :** projet original `KinCity_ArtDeco_V3_Complet (1).zip` + baseline KC33/B09 la plus récente **fournie explicitement** + archive de contribution `KinCity_B04_Campus_UCKK_Contribution.zip`. Lis `docs/RAPPORT_B04.md`, `patch_B04/contrib/places/campus/README.md`, `campus_program.json`, `QA_B04.md` et `handoff_B04.json` avant toute intervention.

## Contrats à préserver

- Place `campus`, bâtiment historique `konnected.university`, secteur `uckk`, accent `#758EA6`, accent commun `#1E6864`.
- Porte entrée `city.konnected.university.entry` depuis la ville ; porte sortie `campus.exit` vers `city.konnected.university.return_spawn`.
- Arrivée `campus.lobby.spawn`, porte `campus.exit.door`, interaction `hall.board_01`, capacité `uckk.courses.browse` encore en mode `stub`.
- Six salles : `campus.lobby`, `campus.gallery`, `campus.chamber`, `campus.west_wing`, `campus.east_wing`, `campus.rear_atrium`; deux passages canoniques et quatre passages de `InteriorWings`.
- Ne créer ni PlaceId, ni capacité kOA réelle imaginaire, ni téléportation sans autorité B09, ni modification de `WorldBuilder` sans RFC.

## Travail déjà réalisé

`CampusDecor.luau` est un module Luau **autonome** produisant des panneaux pédagogiques et moulures Art déco non-collidables, idempotent et limité à la Place `campus`. `INSTALLER_B04_PREVIEW_LOCAL.luau` permet une première prévisualisation dans une copie Studio *locale PlaceId 0* dont le monde existe déjà. Le loader générique B09 n'est pas raccordé : la contribution n'est pas encore visible automatiquement en jeu. Douze tests statiques passent sur le ZIP original, pas sur un checkout KC33/B09 fourni.

## Prochaine grande passe demandée

1. Obtenir les **fichiers réels B09/KC33** et vérifier le SHA de la baseline avant intégration. Ne pas prétendre que cette compatibilité a déjà été prouvée.
2. Comparer la recette B04 fournie avec les conventions `schemas/place_recipe.schema.json` et le registre B09. Conserver ou migrer les données non compatibles via un handoff et une RFC.
3. Exécuter le script de prévisualisation dans une copie locale Studio, vérifier tous les panneaux, leurs faces `SurfaceGui`, les dégagements de portes, les passages, le tableau et les PNJ/équipements déjà présents.
4. Confirmer la cohérence des zones des six salles et le débordement de bounds des ailes ; proposer des ajustements strictement locaux ou une RFC à B09 pour les sources transversales.
5. Développer une expérience pédagogique crédible (cours/exploration/ateliers scientifiques), mais ne pas fabriquer de crédits, bulletins, inscriptions ni API KOALI non connectées. Les interfaces « à venir » doivent rester honnêtes.
6. Optimiser le budget mobile LITE/STANDARD/SHOWCASE ; mesurer réellement après intégration Roblox.
7. Livrer à B09 **un patch isolé**, un `handoff` conforme avec hash/source, preuves Studio disponibles, tests, plan de rollback, risques, et éventuellement une RFC distincte demandant le raccordement du constructeur.

Si tu ne disposes pas de Studio, exécute uniquement les tests possibles et livre le patch avec les preuves des vérifications. La production Roblox ne doit jamais être touchée automatiquement.
