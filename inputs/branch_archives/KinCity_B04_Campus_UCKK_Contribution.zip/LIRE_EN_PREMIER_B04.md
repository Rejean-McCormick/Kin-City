# Kin City — B04 · Campus UCKK

Ce ZIP est une **contribution locale pour B09**, non une expérience Roblox publiée. Pour la fusion, prendre le dossier `patch_B04/contrib/places/campus/` et le handoff `handoff_B04.json`. Il ne faut pas remplacer l'ensemble du projet KC33/B09 avec cette archive.

- **Conception** : `docs/RAPPORT_B04.md`
- **Code Luau autonome** : `patch_B04/contrib/places/campus/CampusDecor.luau`
- **Prévisualisation Command Bar** : `patch_B04/contrib/places/campus/INSTALLER_B04_PREVIEW_LOCAL.luau` (PlaceId 0, copie, Studio en édition seulement)
- **Tests B04** : `patch_B04/contrib/places/campus/tests/test_b04.py` (à placer dans le dépôt complet KC33/B09 et exécuter via unittest)
- **Contrat d'intégration** : `handoff_B04.json`

L'archive B09 générée dans une réponse antérieure est absente du stockage de ce tour. B04 est donc construite depuis le ZIP original fourni par l'utilisateur et non testée contre un checkout KC33/B09. Ne pas enregistrer son handoff comme « ACCEPTED » avant la revue B09.
