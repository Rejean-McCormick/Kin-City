# Rapport B10 — première livraison de la ville centrale

**Date :** 26 octobre 2026. **Source réellement accessible :** ZIP V3 original, SHA256 `6696d12dc6c9fefd845e9180a11c4f9412ea439989ef97bd0ef35eb091192798`. **Référence d'intégration souhaitée :** KC33/B09 (`KC34-DOC-1.0`) non montée dans cette session, donc compatibilité finale à confirmer B09.

## Réalisé

- Module Luau `contrib/places/city/Wayfinding.luau` : orientation de six avenues (jusqu'à 18 repères) et huit entrées canoniques; totems Art déco légers, contrôlés par profil, non bloquants et sans lumières dynamiques.
- Zones de dégagement et repli d'accotement pour ne pas recouvrir les façades ni les anchors; logique de reconstruction idempotente, un seul dossier facilement supprimable.
- Aperçu Studio limité à Place locale non publiée, Play arrêté et monde KC prêt.
- Plan urbain, matrice des couleurs, mobilité future, RFC de raccordement B09, manifeste de contribution, design JSON et recette B10.

## Contrats préservés

- Huit cheminements piétons canoniques, seize portes et neuf Place keys inchangés. Les identifiants historiques ne sont pas renommés.
- Aucune édition dans `catalog/`, `config/`, `src/server/` ou `src/shared/` : **ce paquet est un patch de branche exclusivement**.
- Intérieurs, façades, pavillons, voies de circulation, téléportation et API kOA inchangés.

## Tests

- 17/17 tests statiques B10 PASS sur les sources V3 originales.
- Deux fichiers Luau B10 : délimiteurs et chaînes lexicalement équilibrés; **pas une compilation Luau**.
- Emplacements théoriques : 6/6 secteurs en LITE, 12/12 marques en STANDARD, 18/18 en SHOWCASE; 8/8 bâtiments présents au graphe des portes.
- Aucune exécution Roblox Studio / téléportation client / mesures FPS ; **non testées**.

## Étapes B09

1. Appliquer le patch exclusivement sous `contrib/places/city/` dans la vraie baseline B09 puis reprendre les tests avec `KINCITY_SOURCE_PATH` pointant vers KC33/B09.
2. Vérifier la RFC de raccordement à `CityGenerator` et l'export des modules (révision de `WorldBuilder`), sans écrire dans la production.
3. Lancer le preview dans Studio sur une copie locale et vérifier visibilité, tons, orientation, chevauchements, mobile et collisions.
4. Mesurer coûts en LITE/STANDARD/SHOWCASE ; vérifier les 8 portes et les 6 couleurs dans la ville réellement publiée en staging.
5. Proposer séparément l'enrichissement des façades et les transports si les tests d'urbanisme le justifient.

## Ce qui reste volontairement ouvert

- Génération en production : **non raccordée**, exige approbation B09.
- Bus/tram et véhicule réel : **non construit**; ancien transport non déclaré opérationnel.
- Raffinement complet des façades/pavillons : conservés dans KC33, pas refondus ici.
- Intégration des 80 modèles en bibliothèque : à trier, sans insertion aveugle.
