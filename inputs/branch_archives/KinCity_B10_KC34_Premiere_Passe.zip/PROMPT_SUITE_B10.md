# Suite de B10 — ville centrale Kin City KC34

Lis le paquet `KinCity_B10_KC34_Premiere_Passe.zip` et le ZIP **KC33/B09 réel**, qui n'était pas disponible lors de la première passe B10. L'intégration ne peut pas être considérée comme réalisée avant cette comparaison.

1. Vérifier `handoff_B10.json` et les SHA256 des fichiers dans `contrib/places/city/`. Rejouer les tests B10 avec `KINCITY_SOURCE_PATH` configuré vers la source KC33/B09 exacte et la suite B09 complète.
2. Soumettre `RFC-B10-001-INTEGRATION.md` à B09. Si approuvée, raccorder `Wayfinding.luau` dans le générateur de ville et l'installateur, incrémenter la révision `WorldBuilder` sans toucher aux IDs, aux 16 portes, aux 49 ancres, aux huit intérieurs ou aux catalogues sans migration.
3. Tester la vraie installation dans une copie locale Studio (PlaceId=0); vérifier 6 accents visibles, 8 signalisations d'institutions, zéro collision, zéro panneau hors géométrie, mobile et profil LITE.
4. Produire plan réel d'avenues, intersections, croisements piétons, mobilier Art déco, cohérence du pack KC33, puis RFC transport (sans prétendre que tram ou bus circulent).
5. Tester en staging privé dans un seul univers avec B09, les 8 portes vers l'intérieur et le retour, ainsi que les FPS et mémoire comparables. Ne jamais publier la production automatiquement.
6. Livrer patch, tests Studio réellement exécutés, handoff et proposition de release; sinon livrer un état partiel avec blocages et prompt supplémentaire.
