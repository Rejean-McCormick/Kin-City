# Livraison B03 — Grande Bibliothèque, KC34

**Patch créé et testé statiquement. Non publié dans Roblox.**

## Fichiers importants

- `patch_B03/contrib/places/library/` : contribution autonome, fichiers de scène, JSON, builder Luau, générateur Python, aperçu local Studio et README.
- `handoff_B03.json` : reçu à déposer dans la conversation B09, listant chaque fichier de patch et son SHA-256.
- `PLAN_ET_LIVRAISON_B03.md` : état, réalisations, risques et demandes B09.
- `PROMPT_B03_PASSE_SUIVANTE.md` : continuation détaillée.
- `tests/test_b03.py` et `evidence/tests_B03_offline.log` : 19 contrôles sur la V3 initialement disponible.

**Attention :** l'environnement actuel ne contient que le ZIP V3 fourni au début de la conversation, et pas les ZIP KC33/B09 produits plus tôt. Les chemins, ancres et salles ont été contrôlés contre V3. Le handoff est correctement formaté pour le contrat KC34, mais son champ `baseline_bytes_verified` est faux et son statut est `BLOCKED` tant que B09 ne l'a pas vérifié sur KC33.

## Utilisation

1. Transmettre ce ZIP et `handoff_B03.json` à B09.
2. B09 réapplique `patch_B03/` sur sa vraie baseline KC33, exécute le contrôle des contrats et vérifie la conformité.
3. Sur une copie non publiée `.rbxl` contenant la bibliothèque générée, exécuter `STUDIO_APERCU_LOCAL_B03.luau` depuis la Command Bar Studio en édition, puis inspecter toutes les pièces.
4. Un adaptateur serveur à valider par B09 reste nécessaire pour que cette scène se charge automatiquement dans les Places publiées. N'utiliser aucun script de preview sur une production.
