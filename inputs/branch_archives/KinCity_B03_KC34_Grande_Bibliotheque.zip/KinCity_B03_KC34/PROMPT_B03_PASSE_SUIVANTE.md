# Continuation B03 — Grande Bibliothèque Kin City / KC34

Tu reprends la branche B03 (`place_key=library`, bâtiment `konnected.library`) et **uniquement** celle-ci. Lis le ZIP B03 joint, le `handoff_B03.json`, `PLAN_ET_LIVRAISON_B03.md`, `patch_B03/contrib/places/library/README.md`, le référentiel de contrats KC34 et la baseline logicielle KC33 réellement disponible. Vérifie la concordance de la baseline, ne déduis pas qu'une Place Roblox est publiée parce que le code existe.

Le patch actuel propose 24 décors muraux non collidables sur les six salles, ainsi qu'un constructeur `LibraryScene.luau`, un générateur de données et un script d'aperçu Studio strictement local. Les 19 tests disponibles ont été exécutés sur le package V3 de départ, **pas** sur la baseline KC33/B09 inaccessible au moment de la livraison.

**Travaux prioritaires :**
1. Rejouer les 19 tests sur la vraie baseline KC33, comparer plans/portes/ancres/volumes et résoudre sans modification des contrats partagés.
2. Faire contrôler par B09 la conformité du handoff et l'alignement de l'API future du loader procédural. Ne pas éditer `WorldBuilder` directement en B03.
3. Prévisualiser sur copie `.rbxl` locale avec `STUDIO_APERCU_LOCAL_B03.luau`; vérifier les six salles, les quatre passages d'extension, le retour `library.exit` et le parcours « Le livre sans dernière page ».
4. Évaluer les collision boxes, les ombres, les panneaux lisibles, les couleurs et l'impact des décors sur chaque profil mobile. Supprimer ou réduire les ornements recouvrant la structure existante.
5. Si utile, proposer une sélection de modèles Art déco sous licence provenant du catalogue exact, respecter quotas ArtDecoAssets et secours natifs, avec demande d'approbation B09.
6. Retourner patch/ZIP modifié, preuves de tests et handoff B03 versionné avec risques et rollback. Aucun PlaceId inventé, aucune mutation de production, aucun faux succès Roblox.

Règles : les portes, ancres, IDs de salles, générateurs partagés et palettes communes sont propriété B09/B10. Tout changement `SHARED`/`BREAKING` demande RFC et ADR avant mise en œuvre.
