# Exécution des tests B03

Ces tests comparent le patch à un export **réel** du socle Kin City. Définir la variable `KINCITY_BASELINE_ROOT` sur le dossier `source/Kin-City` extrait de la version à qualifier :

```bash
KINCITY_BASELINE_ROOT=/chemin/KinCity/source/Kin-City \
  python -m unittest discover -s tests -p 'test_b03.py' -v
```

Les 19 cas détectent les écarts des six salles/ancres, les gabarits, les garde-fous d'exécution, la détermination des fichiers générés et une **analyse lexicale** Luau via l'outil du socle. Ils ne compilent pas les scripts dans Roblox Studio et ne testent pas les transitions publiées.
