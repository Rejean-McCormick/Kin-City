"""Offline B03 assertions: layout, safety envelope, receipts, determinism.

Important: no Luau VM/Roblox Studio execution is implied by these tests.
"""
from __future__ import annotations
import hashlib,json,re,unittest,sys,os
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
SRC=ROOT/'patch_B03/contrib/places/library'
BASE=Path(os.environ.get('KINCITY_BASELINE_ROOT', '/__set_KINCITY_BASELINE_ROOT__/source/Kin-City'))
sys.path.insert(0,str(SRC))
import build_tools

LIBRARY_KEY='library'
class B03ContractChecks(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not (BASE/'build/world-plan.json').is_file():
            raise RuntimeError('Set KINCITY_BASELINE_ROOT to the extracted source/Kin-City directory')
        cls.recipe=json.loads((SRC/'scene_plan.json').read_text(encoding='utf8'))
        cls.world=json.loads((BASE/'build/world-plan.json').read_text(encoding='utf8'))
        cls.place=next(p for p in cls.world['places'] if p['place_key']=='library')
        cls.rooms={r['room_id']:r for r in cls.recipe['rooms']}
        cls.scene=(SRC/'LibraryScene.luau').read_text(encoding='utf8')
        cls.studio=(SRC/'STUDIO_APERCU_LOCAL_B03.luau').read_text(encoding='utf8')
    def test_01_room_count_and_id_stability(self):
        self.assertEqual(self.recipe['place_key'],'library')
        self.assertEqual(self.recipe['building_id'],'konnected.library')
        self.assertEqual(len(self.recipe['rooms']),6)
        expected={r['room_id'] for r in self.place['rooms']}|{'library.west_wing','library.east_wing','library.rear_atrium'}
        self.assertEqual(set(self.rooms),expected)
    def test_02_canonical_room_positions_unchanged(self):
        for room in self.place['rooms']:
            spec=self.rooms[room['room_id']]
            self.assertEqual(spec['center_studs'],room['center_studs'])
            self.assertEqual(spec['size_studs'],room['size_studs'])
    def test_03_wing_positions_match_generator(self):
        expected={'library.west_wing':([-79,0,7],[52,16,50]),'library.east_wing':([79,0,7],[52,16,50]),'library.rear_atrium':([0,0,76],[100,16,56])}
        wings=(BASE/'src/server/InteriorWings.luau').read_text(encoding='utf8')
        for room_id,(center,size) in expected.items():
            self.assertIn(room_id,self.rooms)
            self.assertEqual(self.rooms[room_id]['center_studs'],center)
            self.assertEqual(self.rooms[room_id]['size_studs'],size)
            suffix=room_id.split('.')[-1]
            self.assertIn('".'+suffix+'"',wings)
    def test_04_canonical_portal_ids_intact(self):
        doors=json.loads((BASE/'catalog/doors.json').read_text())['doors']
        entry=next(d for d in doors if d['destination_place_key']=='library')
        back=next(d for d in doors if d['source_place_key']=='library')
        self.assertEqual(entry['door_id'],'city.konnected.library.entry')
        self.assertEqual(back['door_id'],'library.exit')
        self.assertEqual(entry['destination_anchor_id'],self.recipe['canonical_doors']['arrival_anchor'])
        self.assertEqual(back['source_anchor_id'],self.recipe['canonical_doors']['return_anchor'])
        self.assertEqual(entry['return_door_id'],back['door_id'])
    def test_05_decor_counts_and_unique_ids(self):
        specs=self.recipe['decorations']
        self.assertEqual(len(specs),24)
        ids=[v['id'] for v in specs]
        self.assertEqual(len(ids),len(set(ids)))
        for spec in specs:
            self.assertTrue(spec['id'].startswith('library.'))
            self.assertIn(spec['room_id'],self.rooms)
            self.assertIn(spec['kind'],('sunburst','frieze','shelf_relief','reading_panel','leaf_motif'))
    def test_06_wall_mount_bounds(self):
        for d in self.recipe['decorations']:
            room=self.rooms[d['room_id']]
            x,y,z=d['position_studs'];cx,_,cz=room['center_studs'];w,_,depth=room['size_studs']
            self.assertGreaterEqual(y,7,d['id']);self.assertLessEqual(y,14,d['id'])
            self.assertLessEqual(abs(x-cx),w/2+1,d['id'])
            self.assertLessEqual(abs(z-cz),depth/2+1,d['id'])
            self.assertTrue(abs(abs(x-cx)-w/2)<4 or abs(abs(z-cz)-depth/2)<4,d['id'])
    def test_07_portal_approaches_clear_of_overlay_centers(self):
        portals=self.place['portals']+[{'center_studs':[-51,0,16]},{'center_studs':[51,0,16]}, {'center_studs':[-27,0,45.5]},{'center_studs':[27,0,45.5]}]
        for d in self.recipe['decorations']:
            x,y,z=d['position_studs']
            for portal in portals:
                px,_,pz=portal['center_studs']
                dist=((x-px)**2+(z-pz)**2)**0.5
                self.assertGreater(dist,7, (d['id'],portal))
    def test_08_profil_budget(self):
        cost={'sunburst':9,'frieze':3,'shelf_relief':10,'reading_panel':4,'leaf_motif':7}
        levels={'LITE':1,'STANDARD':2,'SHOWCASE':3}
        seen=[]
        for profile in levels:
            chosen=[d for d in self.recipe['decorations'] if levels[d['min_profile']]<=levels[profile]]
            parts=sum(cost[d['kind']] for d in chosen)
            seen.append((profile,len(chosen),parts))
            self.assertLessEqual(parts,self.recipe['profile_limits'][profile],seen)
        self.assertEqual([x[1] for x in seen],[12,18,24])
    def test_09_no_gameplay_portal_or_prompt_changes(self):
        forbidden=('TeleportService','ProximityPrompt','library.exit.door','TeleportAsync','KinLibraryStoryAction','TweenService')
        for phrase in forbidden:self.assertNotIn(phrase,self.scene)
        self.assertIn('CanCollide=false',self.scene)
        self.assertIn('CanTouch=false',self.scene)
        self.assertIn('CanQuery=false',self.scene)
    def test_10_scene_requires_library_scoped_context(self):
        self.assertIn('context.authorized==true',self.scene)
        self.assertIn('context.place_key=="library"',self.scene)
        self.assertIn('interior:GetAttribute("KinPlaceKey")=="library"',self.scene)
        self.assertIn('KinB03Owner',self.scene)
    def test_11_preview_is_local_studio_editor_only(self):
        for pattern in ('RunService:IsStudio()','not RunService:IsRunning()','game.PlaceId==0','KinCityGenerated','Intérieur — library'):
            self.assertIn(pattern,self.studio)
        self.assertNotIn('Publish',self.studio)
    def test_12_generated_luau_matches_manifest(self):
        before=(SRC/'LibrarySceneData.luau').read_bytes(),(SRC/'STUDIO_APERCU_LOCAL_B03.luau').read_bytes()
        build_tools.generate(SRC)
        after=(SRC/'LibrarySceneData.luau').read_bytes(),(SRC/'STUDIO_APERCU_LOCAL_B03.luau').read_bytes()
        self.assertEqual(before,after)
    def test_13_no_external_asset_http_script(self):
        for s in ['HttpService','InsertService','GetAsync(','PostAsync(','require(123','loadstring(','script.Source=']:
            self.assertNotIn(s,self.scene)
    def test_14_b09_recipe_shape(self):
        m=json.loads((SRC/'recipe.json').read_text(encoding='utf8'))
        self.assertEqual(m['place_key'],'library')
        self.assertEqual(m['owner_branch'],'B03')
        self.assertEqual(m['requires_contracts_version'],'KC34-DOC-1.0')
        self.assertEqual(m['implementation_status'],'NOT_CONNECTED_TO_WORLD_BUILDER')
    def test_15_preserve_story_book_code(self):
        baseline=(BASE/'src/server/LibraryJourneyArt.luau').read_text(encoding='utf8')
        self.assertIn('LibraryStoryPrompt',baseline)
        self.assertEqual(self.recipe['design_rules']['existing_narrative'],'v28 LibraryJourney - do not duplicate or override prompts')
    def test_16_color_contract(self):
        self.assertEqual(self.recipe['palette']['accent'],'#BC674C')
        self.assertEqual(self.recipe['palette']['teal'],'#1E6864')
    def test_18_luau_lexical_delimiters(self):
        import importlib.util
        path=BASE/'tools/check_luau_structure_v29.py'
        spec=importlib.util.spec_from_file_location('b03_lexical_gate',path)
        module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
        for name in ['LibraryScene.luau','LibrarySceneData.luau','STUDIO_APERCU_LOCAL_B03.luau']:
            with self.subTest(name=name):
                self.assertIsNone(module.check((SRC/name).read_text(encoding='utf8')))
    def test_19_no_branch_shared_changes(self):
        # B03 patch is confined to contrib/places/library; no copied canonics.
        files=list((ROOT/'patch_B03').rglob('*'))
        self.assertTrue(files)
        self.assertTrue(all('contrib/places/library/' in str(f.relative_to(ROOT/'patch_B03')).replace('\\','/')+'/' or
             str(f.relative_to(ROOT/'patch_B03')).startswith('contrib/places/library/')
             for f in files if f.is_file()))
    def test_17_dimensions_extended_envelope_recorded(self):
        for name in ['library.west_wing','library.east_wing','library.rear_atrium']:
            self.assertIn(name,self.rooms)
        lowx=min(r['center_studs'][0]-r['size_studs'][0]/2 for r in self.rooms.values())
        highx=max(r['center_studs'][0]+r['size_studs'][0]/2 for r in self.rooms.values())
        lowz=min(r['center_studs'][2]-r['size_studs'][2]/2 for r in self.rooms.values())
        highz=max(r['center_studs'][2]+r['size_studs'][2]/2 for r in self.rooms.values())
        self.assertEqual([lowx,highx,lowz,highz],[-105,105,-46,104])

if __name__=='__main__':unittest.main(verbosity=2)
