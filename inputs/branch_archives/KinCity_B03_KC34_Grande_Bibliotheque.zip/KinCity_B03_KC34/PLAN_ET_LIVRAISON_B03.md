# B03 / Kin City — Grande Bibliothèque : livraison technique KC34

## Statut

Branche `B03`; territoire `library`. Mise en œuvre visuelle B03 livrée en patch isolé, **non intégrée à KC33/B09** et non validée visuellement Roblox Studio. Aucune modification au plan canonique, aucune publication et aucun PlaceId créé.

## Réalisation

Une proposition architecturale Art déco pour six salles de la Grande Bibliothèque, avec 24 éléments de façade *intérieure* murale, répartis en profils LITE (12), STANDARD (18) et SHOWCASE (24). La palette principale conserve la couleur KonnectED `#BC674C` et le sarcelle commun `#1E6864`. Le parcours narratif des quatre bornes `LibraryJourney` est expressément préservé.

Le module Luau `LibraryScene.luau` crée de la géométrie native non collidable dans le modèle `library` après demande explicite du serveur, de manière idempotente; un aperçu local Studio est généré. Le module n'est pas encore appelé par `WorldBuilder` : le raccordement est réservé à B09.

## Contrats préservés

- Bâtiment `konnected.library`; Place `library`; secteur `konnected`.
- Porte d'entrée `city.konnected.library.entry` vers `library.lobby.spawn` ; retour `library.exit` depuis `library.exit.door`.
- Interaction canonique `hall.bookshelf_01`; aucune nouvelle action métier externe.
- Six IDs de salles et les quatre connecteurs de `InteriorWings`; aucun obstacle de gameplay ajouté.
- Les 23 fichiers du socle KC33 ne sont pas édités par cette branche. Le patch ne contient que `contrib/places/library/*`.

## Résultats des contrôles

19 tests statiques positifs sur la source V3 disponible : noms/centres des six salles, réciprocité des portes, envergure des extensions, collisions déclarées, dégagements des portails, seuils par profil, cohérence des fichiers générés, gardes de l'aperçu et analyse lexicale des délimiteurs Luau. Test de `tree-sitter-luau`, interpréteur Roblox, calcul réel FPS et streaming non exécutés.

## Risques / réserves

1. **Baseline KC33 non accessible dans le présent environnement.** La source fournie aujourd'hui est le ZIP `KinCity_ArtDeco_V3_Complet (1).zip` ; le patch doit être rejoué et validé par B09 sur KC33.
2. B09 n'a pas de loader de recettes procédurales automatiquement raccordé : l'apparition en jeu exige l'acceptation d'une RFC et une intégration serveur explicite.
3. L'absence de collision est vérifiée dans le code, mais l'alignement des ornements avec les murs, l'éclairage et le mobilier déjà placé dans la bibliothèque **doit être contrôlé dans Studio**.
4. Le rendu sera plus riche, mais les 88–145 pièces supplémentaires peuvent dégrader un appareil modeste; aucun gain de performance n'est revendiqué.
5. Aucun modèle commercial Art déco nouveau n'est importé; l'usage des modèles achetés pourra faire l'objet d'une recette séparée sous les quotas B09.

## Demande de décision B09

Approuver la contribution `LOCAL` uniquement après vérification de sa compatibilité KC33 ; décider ensuite d'un schéma `procedural_scene` pour raccorder la scène sans modifier les IDs canoniques ; exécuter les tests Studio et mobile sur copie locale puis staging. **Ne jamais fusionner directement un script Command Bar dans la production.**

## Prochaine passe B03

Intégrer le feedback visuel Studio, corriger les éventuels recouvrements avec le mobilier existant, ajouter éventuellement un nombre limité de modèles Art déco importés sous budget, et préparer les preuves vidéo/photo des six salles et des deux portes. Les détails de transport inter-Place restent sous B09.
