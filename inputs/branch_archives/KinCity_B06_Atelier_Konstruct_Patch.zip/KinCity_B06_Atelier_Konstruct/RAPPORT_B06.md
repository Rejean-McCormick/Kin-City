# B06 · Atelier Konstruct — rapport de première passe

**Proposition à intégrer par B09, version 0.1.0.** Place unique de la branche : `innovation_lab` (Atelier Konstruct, secteur keenKonnect). La Place B10 et les contrats B09 ne sont pas modifiés.

## Fait

- Six salles documentées et coordonnées (3 canoniques + 3 extensions d'`InteriorWings`).
- Six portails protégés : deux depuis le lobby et quatre connecteurs d'extension.
- Deux portes de téléportation conservées, aucun nouvel ID de porte/ancre.
- Palette champagne `#D0BF86`, sarcelle `#1E6864`, style Art déco commun.
- Un module Luau `KonstructScene.luau` généré depuis JSON, avec 24 éléments (frises, enseignes et emblèmes) conditionnels et budgets natifs LITE / STANDARD / SHOWCASE : 24 / 33 / 60 pièces, toutes non collidables.
- Un contrat `recipe.json` préparé pour B09 et une matrice de recette/salles/QA.
- Tests Python statiques : 10 PASS sur les données du **ZIP V3 original fourni par l'utilisateur**.

## Ce qui n'est pas fait / dépendances

Le module B06 n'est **pas connecté** à `WorldBuilder`, ni aux scripts d'installateur de KC33/B09. Les anciens ZIP KC33/B09 produits dans les tours précédents ne sont pas disponibles dans cet environnement de fichiers, donc leur contenu et leurs empreintes **n'ont pas été revérifiés dans cette passe**. La cible contractuelle `KC34-DOC-1.0` et le SHA baseline `1fd3968977823a8814f54f766164c85e02cda3e370df984455f8c3f7db877c89` proviennent de la remise B09 antérieure, non d'une archive rechargée ici.

Pas de test Roblox Studio, de client publié, de collision avatar, d'assets du pack dans cette salle, de ressources consommées en moteur, de TeleportService, de rendu des cartes SurfaceGui ni de mesures mobile. L'outil est un **patch prêt à revoir**, pas une Place installée.

## Risques

- Sens et lisibilité de certaines plaques 3D à vérifier selon caméra et murs réels.
- Frises suspendues à intégrer visuellement; choisir l'emplacement exact après observation de la scène native générée.
- Habillage natif indépendant du pool ArtDecoBudget : B09 doit surveiller l'enveloppe de pièces et agréger le coût réel du bâtiment.
- Dépassement du rectangle de bounds 110×100 dû aux ailes : décision ADR-001 de B09 en attente.
- Sans adaptateur, B06 restera absente des Places publiées.

## Prochaine passe

Livrer à B09 `handoff_B06.json` + `patch_B06/`. B09 examine le diff et la version du contrat, raccorde une première vraie recette de Place dans **une copie locale** puis une Place de staging, vérifie six salles, cinq lignes directrices et six portails; les portes réelles sont à tester dans le client Roblox publié. Ne pas modifier production.
