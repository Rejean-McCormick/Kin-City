#!/usr/bin/env python3
"""Checks patch_B06 bytes, B09 handoff fields, and the local static test log."""
from pathlib import Path
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parent
h=json.loads((ROOT/'handoff_B06.json').read_text(encoding='utf8'))
assert h['branch_id']=='B06' and h['place_key']=='innovation_lab' and h['change_class']=='LOCAL'
assert h['contracts_version']=='KC34-DOC-1.0'
assert len(h['changed_files'])==7
names=set()
for entry in h['changed_files']:
 path=entry['path'];assert path.startswith('contrib/places/innovation_lab/') and '..' not in path
 assert path not in names;names.add(path)
 patch=ROOT/'patch_B06'/path
 assert patch.is_file(),path
 assert hashlib.sha256(patch.read_bytes()).hexdigest()==entry['sha256'],path
 assert patch.read_bytes()==(ROOT/path).read_bytes(),f'Source différent du patch: {path}'
print('Handoff B06 : 7/7 empreintes SHA-256 valides, aucun fichier partagé')
print('Luau source : préparé pour B09, NON exécuté dans Roblox Studio')
