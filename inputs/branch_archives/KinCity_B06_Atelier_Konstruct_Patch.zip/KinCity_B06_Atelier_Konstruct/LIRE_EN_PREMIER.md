# B06 — Atelier Konstruct · Première livraison

**Objectif :** développer en parallèle la Place intérieure `innovation_lab` sans faire dériver les contrats des neuf Places.

## Pour B09

1. Ouvrir `RAPPORT_B06.md` et `handoff_B06.json`.
2. Appliquer **seulement** les fichiers de `patch_B06/contrib/places/innovation_lab/` dans le paquet B09 courant. Ne pas écraser les catalogues, scripts de portes ou la palette.
3. Vérifier les SHA-256 des fichiers du patch et le `baseline_sha256` annoncé dans le handoff. Les ZIP KC33/B09 rédigés précédemment doivent être fournis à B09 pour refaire cette vérification complète.
4. Exécuter `test_b06.py` avec le ZIP V3 original à la racine de ce paquet; les vérifications sont **hors moteur**.
5. Planifier une RFC pour le loader Luau de décor local, puis seulement tester `KonstructScene.build` dans une copie Roblox Studio.

## Ce qui est livré

- `room_layout.json` : 6 salles + 6 portails et 24 décorations prévues.
- `KonstructScene.luau` : module décoratif déterministe et non-collidable (non installé).
- `build_scene.py` : reconstruction du module Luau depuis JSON.
- `recipe.json` : schéma B09 de contributions (`INTEGRATION_PROPOSED`).
- `test_b06.py` : 10 contrôles Python.
- `README.md`, `QA_B06.md` : guide architectural et matrice QA.
- `handoff_B06.json` : remise à B09 avec empreintes des sept fichiers précédents.

## Sécurité

Ne jamais exécuter en Place de production. Il n'y a aucun script d'installation destructeur dans cette livraison. Aucun PlaceId n'est inventé ou renseigné. Aucun modèle sous licence n'est redistribué séparément. Les sources originales fournies sont conservées dans `BASE_KINCITY_V3_ORIGINAL.zip` uniquement comme référence des tests.
