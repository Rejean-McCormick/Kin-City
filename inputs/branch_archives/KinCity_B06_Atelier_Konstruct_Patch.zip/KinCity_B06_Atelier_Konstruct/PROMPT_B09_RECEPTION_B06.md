# Prompt de réception de B06 pour B09

Tu es la branche d'intégration B09 de Kin City. Reçois le ZIP `KinCity_B06_Atelier_Konstruct_Patch.zip` en plus de la baseline officielle KC33 et du paquet d'intégration KC34 B09. La contribution est strictement `innovation_lab` / B06, version 0.1.0, `KC34-DOC-1.0`.

1. Vérifie le `handoff_B06.json` et chaque SHA-256 `changed_files`; refuse une modification hors `contrib/places/innovation_lab/`.
2. Valide `room_layout.json` contre les données canon KC33/B09 réelles : trois salles d'origine, trois extensions, six portails, portes `city.keenkonnect.innovation_lab.entry` et `innovation_lab.exit`, anchor `hall.desk_01`.
3. Contrôle les budgets non-collidables du module `KonstructScene.luau` : LITE 24 parts, STANDARD 33, SHOWCASE 60; empêche sa double génération si autre profil déjà installé.
4. Ne modifie aucun script transverse avant RFC approuvée. Prépare un adaptateur paramétré par `placeKey`, `parent`, `origin`, `profile`, et vérifie son installation dans une copie locale du projet.
5. Teste avec les vraies salles/portails Studio et photographie l'accueil, le bureau, les deux galeries et le hall arrière. Vérifie le sens des panneaux SurfaceGui, les collisions avatar et la mobilité manette/mobile.
6. Ne déclare le patch ACCEPTED qu'après test et preuve. En cas de défaut, renvoie à B06 la liste des corrections; la production reste inchangée.

Livrer à son tour l'intégration ou le rapport de rejet, les tests exécutés, les limites, un rollback et un nouveau handoff. Ne pas prétendre avoir connecté une API externe Koali.
