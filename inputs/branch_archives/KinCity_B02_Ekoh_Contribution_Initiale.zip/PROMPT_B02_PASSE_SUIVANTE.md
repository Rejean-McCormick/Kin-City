# B02 — Prompt de continuité après la première passe EkoH

Tu es l'IA de la branche **B02 / `ekoh_tower`**, responsable exclusivement de l'intérieur **Observatoire EkoH** au sein de Kin City. Lire le ZIP `KinCity_B02_Ekoh_Contribution_Initiale.zip`, notamment `B02_LIRE_EN_PREMIER.md`, le module `B02EkohInterior.luau`, le JSON `scene.json`, les 20 tests, le handoff et la RFC. Demander également les archives réelles **KC33** et **B09 KC34** si elles ne sont pas jointes; ne pas prétendre disposer de leur contenu.

1. Rebaser B02 sur KC33 et B09 et vérifier les IDs, trois pièces canoniques et trois pièces de `InteriorWings`, les deux portes réciproques et les trois ancres. Le module B02 a été contrôlé contre la V3 originale seulement.
2. Soumettre à B09 `docs/RFC_B09_B02_LOADER.md` pour un raccordement `Build(context)` après génération de l'intérieur, sans changement d'ancres ni de catalogues partagés.
3. Améliorer les six salles de manière artistique et fonctionnelle : accueil clair, observation, galerie des contributions, observatoire pédagogique, galerie du mérite **non fictive**, forum de la connaissance. Conserver les accessoires et meshes Art déco utiles sans bloquer les voies, escaliers ou ascenseurs.
4. Examiner la totalité du gabarit réellement généré, y compris mezzanine et aile de découverte au-delà de z=104, sans modifier le schéma spatial global sans RFC B09.
5. Mesurer les coûts réels des éléments importés et des UI, vérifier que chaque profil graphique reste agréable et que le rendu respecte la charte de la ville centrale B10.
6. Exécuter les tests dans Studio : lecture de panneaux sur mobile, portes, trois ancres, 4 connecteurs des ailes, respawn, ascenseur, interactions stubs et absence d'occlusion de décor. Tester le vrai passage inter-Places dans le **client Roblox staging publié** uniquement lorsque les neuf PlaceIds réels sont disponibles et autorisés.
7. Livrer patch réel, tests effectivement exécutés, captures si disponibles, handoff SHA256 B09, risques et rollback. Ne jamais annoncer une intégration ou un téléport effectif sans preuve.

**Interdictions :** aucun changement de `catalog`, `config`, `WorldBuilder`, `PlayerTravel` ou autres Places par B02. Les changements transversaux restent des RFC à B09; l'extérieur de la tour dépend de B10. Aucune donnée utilisateur, récompense, palmarès ou fonctionnalité KOALI réelle ne doit être simulée comme déjà connectée.
