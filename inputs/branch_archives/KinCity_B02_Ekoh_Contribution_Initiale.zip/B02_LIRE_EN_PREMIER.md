# B02 — Observatoire EkoH · contribution initiale prête pour revue B09

**Branche :** B02 · **Place :** `ekoh_tower` · **Bâtiment :** `central.ekoh_tower`  
**Livrable :** module Luau généré + données de décor + tests + rapport + handoff JSON B09.

## Attention — état de la source

La présente session donne accès au fichier utilisateur original `KinCity_ArtDeco_V3_Complet (1).zip` seulement. Les archives KC33 et B09 produites dans les tours antérieurs ne sont pas accessibles ici. Les invariants de géométrie et d'identité EkoH sont confirmés contre le **fichier original V3**, et il faut les revérifier contre **KC33/B09** avant intégration. Le hash de KC33 renseigné dans le handoff est repris du registre B09 de la conversation antérieure, mais **n'a pas pu être recalculé ici**.

## Travail effectivement réalisé

- Conçu le thème intérieur **Atlas du savoir** (sarcelle structurelle + bronze + opale), sans inventer un septième secteur ni de nouvelles données KOALI.
- Six salles repérées, deux portes aller/retour et trois ancres importantes conservées.
- Créé six panneaux 3D/Billboard `SurfaceGui` non interactifs (un par salle), sans collisions, ni import 3D sous licence.
- Livré trois profils de détails : LITE 6 Parts, STANDARD 24 Parts, SHOWCASE 42 Parts, toujours 6 SurfaceGui.
- Ajouté un générateur déterministe de ModuleScript et des contrôles de placement.
- Réussi 20 tests Python B02, validé les données de recette et effectué un contrôle lexical du Luau.

## Ce qu'il reste

1. Charger le vrai KC33 et le ZIP B09, puis comparer les fichiers canoniques et la forme des dossiers d'intérieur : **obligatoire pour lever le statut BLOCKED du handoff**.
2. Déposer `B02EkohInterior.luau` dans le serveur Roblox de test et faire approuver `docs/RFC_B09_B02_LOADER.md` par B09.
3. Raccorder au runtime via la compilation/export existants en ne modifiant pas le contenu des autres Places, puis tester les six panneaux et passages dans Roblox Studio.
4. Tester les deux téléportations dans le client Roblox publié du futur univers staging, et mesurer les profils sur mobile.
5. Affiner les contenus et la direction artistique en accord avec B10/B09, puis préparer des fonctionnalités de savoir réelles uniquement si les APIs deviennent disponibles et autorisées.

Pour la suite, donner ce ZIP à la conversation B09 avec son `handoff_B02.json` et lui demander d'appliquer d'abord le contrôle d'identité de baseline puis de traiter la RFC d'intégration. Aucune Place Roblox n'est créée ou publiée automatiquement.
