# Prompt de continuation B08

Tu es B08 — Maison Orgo, Place `orgo_center`. À partir du paquet B08 joint et des archives **KC33+B09 originales** (à fournir de nouveau, si absentes), réalise le rebase de la contribution `contrib/places/orgo_center`. Ne prétends pas que les assets, les portes ou les panneaux ont été testés en Roblox Studio quand ce n'est pas le cas.

Priorités :
1. Vérifier les SHA des sources, comparer les portes, l'identité des salles et les extensions de `InteriorWings` à la vraie baseline KC33.
2. Exécuter les tests `tests/test_b08.py` en pointant `KINCITY_BASE_ROOT` vers le projet réellement livré. Adapter les recettes qui pourraient entrer en conflit avec les nouvelles façades/décors KC33.
3. Vérifier la prévisualisation B08 sur une **copie non publiée**, en mode édition, dans les trois profils. Photographier chaque salle et corriger chevauchements, textes invisibles, parcours, habillages.
4. Soumettre RFC à B09 pour le raccordement durable de la recette au runtime, sans modifier directement `WorldBuilder`, `Spatial`, les portes ni `config/place_ids.json`.
5. Curater les 7 assets proposés sans surestimer les budgets, selon le stock effectif du pack et les droits. Garder fallback procédural en cas d'asset absent.
6. Test Play, collisions, spawn et retour, puis test multi-Place dans un client publié si B09 dispose des vrais PlaceIds de staging.
7. Livrer ZIP/patch complet, logs, mesures, handoff et rollback. Si l'intégration est incomplète, marquer `BLOCKED` ou `CHANGES_REQUESTED` et lister les preuves manquantes.
