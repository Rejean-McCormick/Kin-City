# Kin City B05 — Agora Korum

1. Consulter `RAPPORT_B05.md` et `contrib/places/justice_palace/README.md`.
2. Remettre `patch_B05/` et `handoff_B05.json` à la branche B09, avec `TESTS_B05.txt`.
3. B09 vérifie les SHA des fichiers et la compatibilité KC33 / KC34 avant fusion.
4. La contribution inclut un constructeur Luau **non raccordé** au runtime. Ne pas l’exécuter dans la production.
5. Les tests hors moteur ne remplacent ni Studio ni les téléportations réelles.

**Portes inchangées :** `city.ethikos.justice_palace.entry` / `justice_palace.exit`. **Six salles** dont trois extensions. **Aucun PlaceId réel créé.**
