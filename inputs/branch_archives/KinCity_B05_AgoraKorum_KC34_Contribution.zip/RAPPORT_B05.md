# B05 — Rapport de livraison au responsable B09

**Version :** B05.KORUM.0.1.0 — `justice_palace` / Agora Korum. **Statut :** contribution locale prête pour revue, non raccordée à l’exécutable Roblox.

## Réalisé

- Six espaces cartographiés avec IDs canoniques et quatre liaisons d’extension protégées.
- Scène Art déco « justice accueillante » : bronze ethiKos `#A97C4F`, sarcelle `#1E6864`, opale et métaux sobres.
- 24 objets décoratifs muraux non-collidables et reproductibles; 6/12/24 selon LITE/STANDARD/SHOWCASE.
- Module Luau `PreviewBuilder.luau` idempotent, scoped à `justice_palace`; chaque objet possède l’attribut de branche `B05`.
- Format de recette `kincity.place-recipe/1.0` conforme aux champs de B09, sans forcer le rattachement à des ancres inadaptées. Les propositions de meshes sont seulement indicatives.
- Aucune modification des 16 portes, de `Spatial`, de `WorldBuilder`, des palettes et de la production.

## Vérifications

**12/12 tests Python hors moteur réussis** : identifiants, salles et ports, zones de dégagement, sources Art déco candidates, estimations par profil, absence d’accès réseau/services Roblox sensibles, stabilité de génération des sources Luau. Voir `TESTS_B05.txt`.

**Non exécuté** : compilation Luau Roblox, rendu des 24 décorations, collisions/ombrages réels, transitions et performances. Le module n’est pas appelé par le runtime courant : **aucun nouvel objet n’existe encore dans une Place publiée**.

**Restriction de base** : seul le ZIP original joint a pu être relu dans cette session. Le SHA KC33 du handoff est repris du rapport précédent B09, non recalculé ici. B09 doit revérifier la compatibilité sur ses ZIP KC33 + KC34/B09 avant d’accepter.

## Décisions sollicitées auprès de B09

1. Valider l’adaptateur de chargement des recettes locales et l’emplacement de rattachement dans l’intérieur B05, sans modifier les autres Places.
2. Déterminer le budget d’instances décoratives et le profil de performance acceptables.
3. Arbitrer la question des bounds (extensions d’InteriorWings hors du rectangle initial) avant QA de colis.
4. Conduire l’installation sécurisée et les tests de portes dans une expérience Roblox de staging privée.

Ce patch est **LOCAL**; aucun changement de contrat partagé n’est demandé.
